# healthyfy
a machine model to predict heartstoke based on your BMI and smoking
