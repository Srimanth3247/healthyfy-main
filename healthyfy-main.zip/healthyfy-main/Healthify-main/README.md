# Healthify
A machine learning model to predict heart stroke on the basis of your BMI and smoking habbits
